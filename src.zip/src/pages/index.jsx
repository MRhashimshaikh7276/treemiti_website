import Header from "../components/header";
import Navbar from "../components/navbar";
import Section from "../components/section";

import styles from '../styles/index.module.css';




function Index(){
return(
    <>
    <main className={styles.main} >
    <Navbar/>
    <Header/>
    <Section/>
    

    </main>
    </>
)
}

export default Index;
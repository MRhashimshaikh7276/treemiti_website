

import Index from "./pages";

function App() {
  return (
    <>
      <Index/>
    </>
  );
}

export default App;

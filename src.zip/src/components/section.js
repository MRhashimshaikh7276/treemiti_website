import Styles from '../styles/section.module.css';


function Section() {
    return(
        <section className={Styles.mainSection}>
            <div className={Styles.absulote}>
                <ul className={Styles.row}>
                    <li>Our Philosophy</li>
                    <li>Design Courses</li>
                    <li>Devlopment Courses</li>
                    <li>Bussiness Courses</li>
                </ul>
            </div>

            
        </section>
    )
}
export default Section;
